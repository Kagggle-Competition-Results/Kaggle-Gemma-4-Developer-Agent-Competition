# Copyright 2026 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import annotations

import contextlib
import dataclasses
import logging
import time
from typing import Any
from typing import AsyncIterator
from typing import TYPE_CHECKING

logger = logging.getLogger("google_adk." + __name__)

from opentelemetry import trace
import opentelemetry.context as context_api

from . import _metrics
from . import tracing
from ..events import event as event_lib

if TYPE_CHECKING:
  from ..agents.base_agent import BaseAgent
  from ..agents.invocation_context import InvocationContext
  from ..tools.base_tool import BaseTool


def _get_elapsed_ms(span: trace.Span | None, fallback_start: float) -> float:
  """Guarantees consistent time source for duration calculation.

  Note: This must be called with an ended span.

  Args:
    span (trace.Span | None): The ended span to extract duration from.
    fallback_start (float): Fallback start time in seconds (monotonic).

  Returns:
    float: Elapsed duration in milliseconds.
  """
  if span is None:
    return (time.monotonic() - fallback_start) * 1000

  start_ns = getattr(span, "start_time", None)
  end_ns = getattr(span, "end_time", None)

  if isinstance(start_ns, int) and isinstance(end_ns, int):
    return (end_ns - start_ns) / 1e6  # Convert ns to ms

  # Fallback if span times are missing
  return (time.monotonic() - fallback_start) * 1000


@dataclasses.dataclass
class TelemetryContext:
  """Stores all telemetry related state."""

  otel_context: context_api.Context
  function_response_event: event_lib.Event | None = None


@contextlib.asynccontextmanager
async def record_agent_invocation(
    ctx: InvocationContext, agent: BaseAgent
) -> AsyncIterator[TelemetryContext]:
  """Unified context manager for consolidated metrics and tracing."""
  start_time = time.monotonic()
  caught_error: Exception | None = None
  span: trace.Span | None = None
  span_name = f"invoke_agent {agent.name}"
  try:
    with tracing.tracer.start_as_current_span(span_name) as s:
      span = s
      tracing.trace_agent_invocation(span, agent, ctx)
      tel_ctx = TelemetryContext(otel_context=context_api.get_current())
      yield tel_ctx
  except Exception as e:
    caught_error = e
    raise
  finally:
    elapsed_ms = _get_elapsed_ms(span, start_time)
    try:
      _metrics.record_agent_invocation_duration(
          agent.name,
          elapsed_ms,
          caught_error,
      )
      _metrics.record_agent_request_size(agent.name, ctx.user_content)
      _metrics.record_agent_response_size(agent.name, ctx.session.events)
      _metrics.record_agent_workflow_steps(agent.name, ctx.session.events)
    except Exception:  # pylint: disable=broad-exception-caught
      logger.exception(
          "Failed to record agent metrics for agent %s", agent.name
      )


@contextlib.asynccontextmanager
async def record_tool_execution(
    tool: BaseTool,
    agent: BaseAgent,
    function_args: dict[str, Any],
) -> AsyncIterator[TelemetryContext]:
  """Unified context manager for consolidated tool execution telemetry."""
  start_time = time.monotonic()
  caught_error: Exception | None = None
  span: trace.Span | None = None
  span_name = f"execute_tool {tool.name}"
  try:
    with tracing.tracer.start_as_current_span(span_name) as s:
      span = s
      tel_ctx = TelemetryContext(otel_context=context_api.get_current())
      try:
        yield tel_ctx
      except Exception as e:
        caught_error = e
        raise
      finally:
        response_event = (
            tel_ctx.function_response_event if caught_error is None else None
        )
        tracing.trace_tool_call(
            tool=tool,
            args=function_args,
            function_response_event=response_event,
            error=caught_error,
        )
  finally:
    try:
      _metrics.record_tool_execution_duration(
          tool_name=tool.name,
          agent_name=agent.name,
          elapsed_ms=_get_elapsed_ms(span, start_time),
          error=caught_error,
      )
    except Exception:  # pylint: disable=broad-exception-caught
      logger.exception(
          "Failed to record tool execution duration for tool %s", tool.name
      )
