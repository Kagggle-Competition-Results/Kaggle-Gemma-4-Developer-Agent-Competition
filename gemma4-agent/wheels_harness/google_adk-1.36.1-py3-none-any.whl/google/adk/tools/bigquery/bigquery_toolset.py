# Copyright 2026 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import annotations

from typing import List
from typing import Optional
from typing import Union

from google.adk.agents.readonly_context import ReadonlyContext
from typing_extensions import override

from . import data_insights_tool
from . import metadata_tool
from . import query_tool
from . import search_tool
from ...features import FeatureName
from ...tools.base_tool import BaseTool
from ...tools.base_toolset import BaseToolset
from ...tools.base_toolset import ToolPredicate
from ...tools.google_tool import GoogleTool
from .bigquery_credentials import BigQueryCredentialsConfig
from .config import BigQueryToolConfig


class BigQueryToolset(BaseToolset):
  """BigQuery Toolset contains tools for interacting with BigQuery data and metadata."""

  def __init__(
      self,
      *,
      tool_filter: Optional[Union[ToolPredicate, List[str]]] = None,
      credentials_config: Optional[BigQueryCredentialsConfig] = None,
      bigquery_tool_config: Optional[BigQueryToolConfig] = None,
  ):
    super().__init__(tool_filter=tool_filter)
    self._credentials_config = credentials_config
    self._tool_settings = (
        bigquery_tool_config if bigquery_tool_config else BigQueryToolConfig()
    )

  def _is_tool_selected(
      self, tool: BaseTool, readonly_context: ReadonlyContext
  ) -> bool:
    if self.tool_filter is None:
      return True

    if isinstance(self.tool_filter, ToolPredicate):
      return self.tool_filter(tool, readonly_context)

    if isinstance(self.tool_filter, list):
      return tool.name in self.tool_filter

    return False

  @override
  async def get_tools(
      self, readonly_context: Optional[ReadonlyContext] = None
  ) -> List[BaseTool]:
    """Get tools from the toolset."""
    all_tools = [
        GoogleTool(
            func=func,
            credentials_config=self._credentials_config,
            tool_settings=self._tool_settings,
        )
        for func in [
            metadata_tool.get_dataset_info,
            metadata_tool.get_table_info,
            metadata_tool.list_dataset_ids,
            metadata_tool.list_table_ids,
            metadata_tool.get_job_info,
            query_tool.get_execute_sql(self._tool_settings),
            query_tool.forecast,
            query_tool.analyze_contribution,
            query_tool.detect_anomalies,
            data_insights_tool.ask_data_insights,
            search_tool.search_catalog,
        ]
    ]

    return [
        tool
        for tool in all_tools
        if self._is_tool_selected(tool, readonly_context)
    ]

  @override
  async def close(self):
    pass
