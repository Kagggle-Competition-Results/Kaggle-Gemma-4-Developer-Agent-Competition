# Copyright 2026 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import annotations

from pydantic import BaseModel

from ...features import experimental
from ...features import FeatureName


@experimental(FeatureName.BIGTABLE_TOOL_SETTINGS)
class BigtableToolSettings(BaseModel):
  """Settings for Bigtable tools."""

  max_query_result_rows: int = 50
  """Maximum number of rows to return from a query result."""
